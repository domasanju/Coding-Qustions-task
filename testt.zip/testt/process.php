<?php
include('dbcon.php');
include_once('functions.php');

//include_once('functions.php');
if(isset($_REQUEST['action']))
{
	switch(strtolower($_REQUEST['action']))
	{
		case 'delete_record':
		 if(delete_record($_REQUEST['delete_id']))
				echo "<script>window.location='dashboard.php';alert('Record Deleted Successfully');</script>";
			else 
				echo "<script>window.location='dashboard.php';alert('Record Not Deleted, try again');</script>";
		break;
		
			case 'student_update':
						//echo "<script>'alert(called)'</script>";		
		    echo student_update($_REQUEST['id']);
		break;
		
		case 'viewstudent':
						//echo "<script>'alert(called)'</script>";		
		    echo viewstudent($_REQUEST['id']);
		break;
		
		case 'update_records':
		   if(update_records($_REQUEST['hide_field1'],$_REQUEST['studid1'],$_REQUEST['studname1'],$_REQUEST['class1'],$_REQUEST['email1'],$_REQUEST['enrollyr'],$_REQUEST['city1'],$_REQUEST['country1']))
			   
		       echo "<script>window.location='dashboard.php';alert('Record Updated Successfully');</script>";
		   else
			   echo "<script>window.location='dashboard.php';alert('Record Not Updated');</script>";
		 break;
	}
}