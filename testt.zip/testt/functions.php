<?php 
	  include('dbcon.php');
function delete_record($delete_id)
	{
		$query = mysql_query("delete from stud_registration where stud_id='$delete_id'");
		if($query)
			return true;
		else{ 
			return false;
		}
		
	} 
	function viewstudent($id) 
	{	
		$data=[];
		if (!empty($id)) 
		{
			$sql = "SELECT * FROM `stud_registration` WHERE `Stud_id` = '".$id."'";
	        $query = mysql_query($sql) or trigger_error("Query Failed: " . mysql_error());
			if(mysql_affected_rows() > 0)
			{
			while($res=mysql_fetch_array($query))
			{				
				$data['Stud_id']=$res['Stud_id'];
				$data['stud_name']=$res['stud_name'];
				$data['email']=$res['email'];
				$data['class']=$res['class'];
				$data['enroll_year']=$res['enroll_year'];
				$data['city']=$res['city'];
				$data['country']=$res['country'];
			}
			
			}	
         return json_encode($data);	
			
		}
	
	}
		function student_update($id) 
	{	
		$data=[];
		if (!empty($id)) 
		{
			$sql = "SELECT * FROM `stud_registration` WHERE `Stud_id` = '".$id."'";
	        $query = mysql_query($sql) or trigger_error("Query Failed: " . mysql_error());
			if(mysql_affected_rows() > 0)
			{
			while($res=mysql_fetch_array($query))
			{				
				$data['Stud_id']=$res['Stud_id'];
				$data['stud_name']=$res['stud_name'];
				$data['email']=$res['email'];
				$data['class']=$res['class'];
				$data['enroll_year']=$res['enroll_year'];
				$data['city']=$res['city'];
				$data['country']=$res['country'];
			}
			
			}	
         return json_encode($data);	
			
		}
	
	}
	
	function update_records($hide_field1,$studid1,$studname1,$class1,$email1,$enrollyr,$city1,$country1)
     {
	 $query = mysql_query("update `stud_registration` set stud_name='$studname1',class='$class1',email='$email1',enroll_year='$enrollyr',city='$city1',country='$country1' where Stud_id='$hide_field1'");
	  
	  
	 
	  // echo "update post_schedule set dept='$post_dept',category='$post_category',grade_pay='$post_gradepay',mode_of_filling='$post_fill',ss='$post_ss',mor='$post_mor',vac='$post_vac',vac_in_hg='$post_vacinhg',utrg='$post_trg',netvac='$post_netvac',date_of_ass='$post_dateass',date_of_noti='$post_datenot',date_of_exam='$post_dateexam',date_of_panel='$post_datepanel',action_plan='$post_plan' where id='$hide_field'".mysql_error();
	  
	 if($query)
	 {
		 return true;
	 }
	 else
	 {
		 return false;
	 }
     }

?>