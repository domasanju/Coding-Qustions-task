<?php 
	  include('dbcon.php');
		$sname = $_GET['studname'];
		$class = $_GET['class'];
		$email = $_GET['email'];
		$enroll = $_GET['enroll_yr'];
		$city = $_GET['city'];
		$country = $_GET['country'];
//$pass2 = $_GET['cpass'];

		
		$sql=mysql_query("insert into stud_registration(stud_name,email,class,enroll_year,city,country)values('$sname','$email','$class','$enroll','$city','$country')");
			if($sql){
				echo "<script>window.location='dashboard.php';alert('Record inserted Successfull');</script>";
			}else{
				echo "<script>window.location='dashboard.php';alert('Record Not Insserted, please try again');</script>";
			}
			
?>
		