<html>
<script type="text/javascript">
    function Validate() {
        var password = document.getElementById("pass").value;
        var confirmPassword = document.getElementById("cpass").value;
        if (password != confirmPassword) {
            alert("Passwords does not match.");
            return false;
        }
        return true;
    }
	function ValidateEmail(mail) 
{
 if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(main.email.value))
  {
    return (true)
  }
    alert("You have entered an invalid email address!")
    return (false)
}


</script>
<body>
<form name="main" action="dosignup.php">
<center>
<h1>Registration Page</h1>
</center>
<center>
<table colspan="10" cellpadding="5" cellspacing="10" width="10"><tr><td>
<label>First Name:</label><input type="text" name="fname" id="fname" required></td></tr>
<tr><td>
<label>Middle Name:</label>:<input type="text" name="mname" id="mname"></td></tr>
<tr><td>
<label>Last Name:</label>:<input type="text" name="lname" id="lname" required></td></tr>
<tr><td>
<label> Email:</label>:<input type="text" name="email" id="email"  required ></td></tr>
<tr><td>
<label>Mobile No.:</label>:<input type="text" name="mbno" id="mbno"  maxlength="10" onkeypress='return event.charCode >= 48 && event.charCode <= 57'></td></tr>
<tr><td>
<label>Password:</label>:<input type="password" name="pass" id="pass" required></td></tr>
<tr><td>
<label>Confirm Password:</label>:<input type="password" name="cpass" id="cpass" required></td></tr>
<tr><td></td>
<td>
<input type="submit" name="submit" value="Signup" onclick="return Validate(),ValidateEmail()"/></td></tr>
</table>
</center>
</form>
</body>
</html>